Supplementary material for "Bold Without Bars: What Three Years of AAMAS Tables Let a Reader Check"

supplement.pdf        the supplementary text: reader protocols verbatim, classifier prompt,
                      per-paper protocol table, every scoring of the reference set, and the
                      list of reference items where reader and parser disagree
numbers.tex           every number in the paper as a LaTeX macro, generated from the run records
run_records/          the run records the macros are built from, including the per-comparison
                      database (analysis.json), the evaluation-protocol readings, the community labels
audits/               the reference-set and random-page items with the readers' labels

The full code release (the frozen parser, the AAMAS scripts, the extraction file, and the
rendered audit images) is at the anonymous repository named in the paper's Reproducibility
statement; run_all_aamas.sh there regenerates every number without network access.
